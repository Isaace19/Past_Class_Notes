#include ...

class prime_partition {
  public:
    prime_partition();

    other functions needed

    void find_partition(int);

  private:
    void expand_pset(arguments);
    bool is_valid(arguments)
    bool find_partition(arguments)

    pset and other data members 
};
