#include ...

prime_partition::prime_partition() {
  set number of terms = 3
  set pset = { 2 }
}

void prime_partition::find_partition(int number) {
  if (largest known prime < number) {
    expand pset to cover number

    if (verbose)
	  print contents of pset
  }

  call recursive find_partition(number, 0) 

  if (solution not found)
    Goldbach's conjecture proven wrong!!
  else
  if (!verbose)
    print partition
}

void prime_partition::expand_pset(int number) {
  let pset_max = max(pset)
  next_prime = pset_max+1;

  while (pset_max < number) {
    if (next_prime%k != 0 for all k in pset) { 
	  insert next_prime into pset, update pset_max
	}

	increment next_prime 
  }
}

bool prime_partition::is_valid(number, terms) {
  return true or false based on arguments
}

bool prime_partition::find_partition(number, terms) {
  base case: number == 0

  if (verbose)
	print incremental solution 

  for k in pset where k < upperbound(number) {
    add k to partition

    if (number-k is valid) {
      call find_partition(number-k, terms+1) 
	  if solution found, 
	    terminate backtracking 
	}

    remove k from partition
  }
}
