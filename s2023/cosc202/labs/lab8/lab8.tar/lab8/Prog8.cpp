#include ...

int main(int argc, char *argv[])
{
  prime_partition goldbach;

  process command line arguments

  if (bad or missing arguments) {
    print meaningful error message
    return 1;
  }

  while (1) {
    stdin: prompt for number
    check for end-of-file
    
    check number is not too small

    goldbach.find_partition(number);
  }

  return 0;
}
