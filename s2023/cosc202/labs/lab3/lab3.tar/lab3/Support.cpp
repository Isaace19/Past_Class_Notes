#include <something>
#include "support.h"

write code for isprime member functions
