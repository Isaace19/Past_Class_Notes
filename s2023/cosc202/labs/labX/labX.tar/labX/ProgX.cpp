#include ...

int main(int argc, char *argv) {
   command line argument handling

   part 1: read and print rawdata
   part 2: create and print summaries
}
