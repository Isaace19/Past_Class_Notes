#include ...
using namespace std;

struct location {
  string city;
  string state;
  string geocode;

  bool operator<()
  void print() 
};

struct rawdata {
  int month;
  float precip;
  int temp;

  void print()
};

struct summary {
  int N;

  float precip_avg;
  float precip_max;
  float precip_min;

  float temp_avg;
  float temp_max;
  float temp_min;

  summary();
  void operator+()
  void print()
};

class database {
  public:
    void init_rawdata(filename)
    void print_rawdata()

    void init_summary()
    void print_summary(target)

  private:
    void extract_rawdata()
    void extract_summary();

    // map: location --> data
    // vector<list>: rawdata 
    datatype location_map;
    datatype rawdata_cache;

    // hash map: state --> geocode 
    // hash map: geocode --> location
    // vector<vector>: summary
    datatype state_map;
    datatype geocode_map;
    datatype summary_cache;
};
