#include ...

write location member functions

write rawdata member functions

write summary member functions

write database member functions
